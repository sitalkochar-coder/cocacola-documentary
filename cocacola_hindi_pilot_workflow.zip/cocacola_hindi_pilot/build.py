import asyncio, json, os, re, subprocess, sys, time
from pathlib import Path
from urllib.parse import quote
import requests
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).parent
OUT = ROOT / "output"
WORK = ROOT / "work"
ASSETS = ROOT / "assets"
OUT.mkdir(exist_ok=True); WORK.mkdir(exist_ok=True); ASSETS.mkdir(exist_ok=True)

def run(cmd):
    subprocess.run(cmd, check=True)

def duration(path):
    result = subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path)
    ], text=True)
    return float(result.strip())

def commons_image(query, index):
    """Fetch a freely licensed image from Wikimedia Commons, with attribution metadata."""
    api = "https://commons.wikimedia.org/w/api.php"
    params = {
        "action": "query", "generator": "search", "gsrsearch": query,
        "gsrnamespace": 6, "gsrlimit": 8,
        "prop": "imageinfo", "iiprop": "url|extmetadata",
        "iiurlwidth": 1600, "format": "json"
    }
    headers = {"User-Agent": "HindiDocumentaryPilot/1.0 (educational project)"}
    try:
        data = requests.get(api, params=params, headers=headers, timeout=30).json()
        pages = list(data.get("query", {}).get("pages", {}).values())
        for page in pages:
            info = (page.get("imageinfo") or [{}])[0]
            meta = info.get("extmetadata", {})
            license_name = meta.get("LicenseShortName", {}).get("value", "License not stated")
            artist = meta.get("Artist", {}).get("value", "Author not listed")
            source_url = info.get("descriptionurl", "")
            # Avoid files whose metadata explicitly says non-free / fair use.
            if "fair use" in license_name.lower() or "non-free" in license_name.lower():
                continue
            url = info.get("thumburl") or info.get("url")
            if not url: 
                continue
            img = requests.get(url, headers=headers, timeout=40)
            img.raise_for_status()
            path = WORK / f"scene_{index:02d}.jpg"
            path.write_bytes(img.content)
            return path, f"Scene {index}: {page.get('title','')}\nCreator: {artist}\nLicense: {license_name}\nSource: {source_url}\n"
    except Exception as e:
        print(f"Commons lookup failed for {query}: {e}")
    return None, ""

def fallback_image(index, title):
    # Simple designed fallback if Commons search has no suitable result.
    img = Image.new("RGB", (1920, 1080), (18, 18, 24))
    d = ImageDraw.Draw(img)
    d.rectangle((0, 0, 1920, 1080), fill=(25, 16, 20))
    d.ellipse((1250, 120, 1900, 770), fill=(105, 12, 25))
    d.rectangle((0, 850, 1920, 1080), fill=(12, 12, 18))
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 58)
    except:
        font = ImageFont.load_default()
    d.text((100, 420), title, fill=(245, 235, 225), font=font)
    d.text((100, 510), "Historical visual unavailable — replace with a verified image", fill=(210, 190, 190), font=font)
    path = WORK / f"scene_{index:02d}.jpg"
    img.save(path, quality=90)
    return path

async def make_audio(text, voice, path):
    import edge_tts
    communicate = edge_tts.Communicate(text, voice)
    await communicate.save(str(path))

def srt_time(seconds):
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3600000); m, ms = divmod(ms, 60000); s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def main():
    script = json.loads((ROOT / "script.json").read_text(encoding="utf-8"))
    voice = os.getenv("TTS_VOICE", script.get("voice", "hi-IN-MadhurNeural"))
    attributions = []
    audio_files, image_files, subtitles = [], [], []
    current = 0.0

    for i, scene in enumerate(script["scenes"], 1):
        audio = WORK / f"audio_{i:02d}.mp3"
        asyncio.run(make_audio(scene["text"], voice, audio))
        audio_len = duration(audio)
        img, attribution = commons_image(scene["visual_query"], i)
        if img is None:
            img = fallback_image(i, scene["visual_query"])
            attribution = f"Scene {i}: Generated fallback graphic; no external image used.\n"
        audio_files.append(audio); image_files.append(img); attributions.append(attribution)
        subtitles.append((current, current + audio_len, scene["text"]))
        current += audio_len

    # Render one still-image segment per narration block, using a gentle zoom.
    segments = []
    for i, (audio, img) in enumerate(zip(audio_files, image_files), 1):
        length = duration(audio)
        seg = WORK / f"segment_{i:02d}.mp4"
        vf = (
            "scale=1920:1080:force_original_aspect_ratio=increase,"
            "crop=1920:1080,zoompan=z='min(zoom+0.0005,1.08)':"
            "x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
            "d=1:s=1920x1080:fps=25,format=yuv420p"
        )
        run(["ffmpeg", "-y", "-loop", "1", "-i", str(img), "-i", str(audio),
             "-vf", vf, "-t", f"{length:.3f}", "-r", "25",
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
             "-c:a", "aac", "-b:a", "160k", "-shortest", str(seg)])
        segments.append(seg)

    concat_file = WORK / "concat.txt"
    concat_file.write_text("".join(f"file '{p.as_posix()}'\n" for p in segments), encoding="utf-8")
    final_video = OUT / "cocacola_hindi_pilot.mp4"
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file),
         "-c", "copy", str(final_video)])

    srt = OUT / "cocacola_hindi_pilot.srt"
    with srt.open("w", encoding="utf-8") as f:
        for n, (start, end, text) in enumerate(subtitles, 1):
            f.write(f"{n}\n{srt_time(start)} --> {srt_time(end)}\n{text}\n\n")
    (OUT / "image_attributions.txt").write_text(
        "IMAGE ATTRIBUTIONS — review before publishing\n\n" + "\n".join(attributions),
        encoding="utf-8"
    )
    print(f"\nCreated: {final_video}")
    print(f"Duration: {duration(final_video):.1f} seconds")
    print(f"Subtitles: {srt}")
    print("Review every downloaded image and its license before publishing.")

if __name__ == "__main__":
    main()
